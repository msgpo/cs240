package client;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

public class AddressPanel extends JPanel {

	public AddressPanel(){
		//address panel has the server info and password and "GO" button
		
