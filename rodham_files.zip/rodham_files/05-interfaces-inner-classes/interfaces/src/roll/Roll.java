package roll;

public interface Roll {
    
    public void addName(String newName);
    public void removeName(String oldName);
    public int size();
}
