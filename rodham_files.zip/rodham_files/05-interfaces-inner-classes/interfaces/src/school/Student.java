package school;

public class Student extends Person {

	public Student(int id, String name) {
		super(id, name);
	}

}
