package school;

public interface Advisor {

	void addStudent(Student s);
	void removeStudent(Student s);
	Student[] getStudents();
}
