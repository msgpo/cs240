package anonymousinnerclass;

public interface Iterator {

	boolean hasNext();
	int getNext();
}
