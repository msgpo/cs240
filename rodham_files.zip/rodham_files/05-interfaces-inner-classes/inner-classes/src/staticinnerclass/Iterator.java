package staticinnerclass;

public interface Iterator {

	boolean hasNext();
	int getNext();
}
