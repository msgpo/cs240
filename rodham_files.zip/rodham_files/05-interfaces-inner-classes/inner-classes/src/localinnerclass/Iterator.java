package localinnerclass;

public interface Iterator {

	boolean hasNext();
	int getNext();
}
