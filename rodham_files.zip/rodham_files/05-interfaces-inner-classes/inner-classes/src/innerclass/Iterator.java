package innerclass;

public interface Iterator {

	boolean hasNext();
	int getNext();
}
