

public interface DrawingListener {

	void originChanged(int w_newOriginX, int w_newOriginY);
}
