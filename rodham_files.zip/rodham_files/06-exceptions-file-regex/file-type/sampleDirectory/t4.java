public static void t4 {
    public static void main(String[] args){
        System.out.println("This is t4");
    }
}
