public static void t2 {
    public static void main(String[] args){
    }
}
