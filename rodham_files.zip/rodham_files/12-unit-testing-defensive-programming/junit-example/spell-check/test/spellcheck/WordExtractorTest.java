
package spellcheck;

import org.junit.* ;
import static org.junit.Assert.* ;

import java.util.*;


public class WordExtractorTest {

	private WordExtractor extractor;
	private List<String> expected;

	@Before
	public void setUp() {
		extractor = new WordExtractor();
		expected = new ArrayList<String>();
	}

	@After
	public void tearDown() {
		return;
	}

	@Test
	public void testEmptyContent() {
		String content = "";
		List<String> actual = extractor.extract(content);
		assertEquals(expected, actual);
	}

	@Test
	public void testOneShortWord() {
		String content = "a";

		expected.add("a");

		List<String> actual = extractor.extract(content);
		assertEquals(expected, actual);
	}

	@Test
	public void testOneLongWord() {
		String content = "thisisareallylongword";

		expected.add("thisisareallylongword");

		List<String> actual = extractor.extract(content);
		assertEquals(expected, actual);
	}

	@Test
	public void testOneShortWordWithSurroundingWhitespace() {
		String content = " \t\n\ra \t\n\r";

		expected.add("a");

		List<String> actual = extractor.extract(content);
		assertEquals(expected, actual);
	}

	@Test
	public void testOneLongWordWithSurroundingWhitespace() {
		String content = " \t\n\rthisisareallylongword \t\n\r";

		expected.add("thisisareallylongword");

		List<String> actual = extractor.extract(content);
		assertEquals(expected, actual);
	}

	@Test
	public void testTypicalContent() {
		String content = "\nfour score\nand seven\n\nyears ago\nour fathers\n";

		expected.add("four");
		expected.add("score");
		expected.add("and");
		expected.add("seven");
		expected.add("years");
		expected.add("ago");
		expected.add("our");
		expected.add("fathers");

		List<String> actual = extractor.extract(content);
		assertEquals(expected, actual);
	}

	@Test
	public void testNonAlphaCharacters() {
		String content = "\n4 ??score\nand*** -- 7\n\nyears ago<><>\nour fathers\n";

		expected.add("score");
		expected.add("and");
		expected.add("years");
		expected.add("ago");
		expected.add("our");
		expected.add("fathers");

		List<String> actual = extractor.extract(content);
		assertEquals(expected, actual);
	}
	
}


