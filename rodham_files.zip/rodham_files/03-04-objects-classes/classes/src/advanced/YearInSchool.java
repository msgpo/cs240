package advanced;

public enum YearInSchool { 
	FRESHMAN, 
	SOPHOMORE, 
	JUNIOR, 
	SENIOR 
}