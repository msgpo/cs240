package work;

import base.Person;

public class Manager extends Person {

	public Manager(String name, int age) {
		super(name, age);
		// TODO Auto-generated constructor stub
	}

}
