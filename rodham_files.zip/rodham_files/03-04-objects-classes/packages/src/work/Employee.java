package work;

import base.Person;

public class Employee extends Person {

	public Employee(String name, int age) {
		super(name, age);
		// TODO Auto-generated constructor stub
	}

}
